import {StyleSheet} from 'react-native';

export default StyleSheet.create({
    container:{

    },
    touchable:{
        position:'absolute',
        left:12,
        top:22,
        height:50,
        width:50
    },
    backImage:{
        height:16,
        width:8,
        marginTop:30,
        marginLeft:20,
        
        
    },
    loloImage:{
        height:38,
        width:113,
        alignSelf:'center',
        marginTop:45,
        resizeMode:'contain'
    }

})