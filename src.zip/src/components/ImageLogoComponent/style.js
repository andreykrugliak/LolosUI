import {StyleSheet} from 'react-native';
export default{

    imageView:{
        height:141,
        width:289,
        backgroundColor:"#EC909B",
        alignSelf:"center",
    },
imgLogo:{
    position:"absolute",
    alignSelf:"center",
    height:141,
    width:289,
    backgroundColor:"#EC909B"
}}