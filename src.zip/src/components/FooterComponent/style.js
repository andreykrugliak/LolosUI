import {StyleSheet} from 'react-native'
export default {
    container : {
        backgroundColor: "#FF4273",
        flexDirection: "column"
    },
    continueBtnText : {
        color: "rgba(255,255,255,0.9)",
        fontSize: 18,
        fontFamily:"Lato-Black",
        alignSelf: "center"
    },
    ButtonContainer : {
        justifyContent: "center"
    }
}