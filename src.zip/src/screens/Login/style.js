import {StyleSheet} from 'react-native'
export default {
    container : {
        flex:1,
        backgroundColor:"#fff"
    },

   
    subTitle : {
        fontSize: 24,
        marginTop: 99,
        alignSelf: 'center',
        fontFamily:'Lato-Bold'
    },
    mainTitle : {
        fontSize: 41,
        color: '#FF4273',
        alignSelf: 'center',
        fontFamily:'PatuaOne-Regular'
    },
   
    footerContainer:{
       backgroundColor:'pink',
       marginTop:200
      
    },
    SigninText:{
        backgroundColor:'transparent',
        fontSize:18,
        color:'white',
        marginTop:12,
        fontFamily:"Lato-Black"
    },
   
}